import json
import pathlib
import subprocess
import sys
import winreg

ROOT = pathlib.Path(__file__).resolve().parent
KEY = r'Software\Google\Chrome\NativeMessagingHosts\local.behance_idm_helper'

def install():
    if sys.version_info < (3, 10):
        raise RuntimeError('Python 3.10 or newer is required.')
    vendor = ROOT / 'vendor'
    if not (vendor / 'comtypes' / '__init__.py').is_file():
        subprocess.run([sys.executable, '-m', 'pip', 'install', '--target', str(vendor), '-r', str(ROOT/'requirements.txt')], check=True)
    subprocess.run([sys.executable, '-c', 'import sys; sys.path.insert(0, sys.argv[1]); import comtypes.client', str(vendor)], check=True)
    settings = json.loads((ROOT/'settings.json').read_text(encoding='utf-8'))
    # The first two ASCII lines set UTF-8 before the path-bearing line is read.
    launcher = '@echo off\r\nchcp 65001 >nul\r\n"' + sys.executable + '" "%~dp0host.py" %*\r\n'
    (ROOT/'native-host.cmd').write_bytes(launcher.encode('utf-8'))
    manifest = {'name':'local.behance_idm_helper','description':'Personal Behance to IDM helper',
        'path':str(ROOT/'native-host.cmd'),'type':'stdio',
        'allowed_origins':['chrome-extension://'+settings['extensionId']+'/']}
    target=ROOT/'native-host.json'
    target.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    origin=manifest['allowed_origins'][0]
    import struct
    message=json.dumps({'action':'ping'}).encode()
    proc=subprocess.run([sys.executable,str(ROOT/'host.py'),origin],input=struct.pack('<I',len(message))+message,capture_output=True,timeout=15)
    if proc.returncode or len(proc.stdout)<4 or not json.loads(proc.stdout[4:]).get('ok'):
        raise RuntimeError('Local host self-check failed. Registration was not changed.')
    with winreg.CreateKeyEx(winreg.HKEY_CURRENT_USER,KEY,0,winreg.KEY_SET_VALUE) as key:
        winreg.SetValueEx(key,'',0,winreg.REG_SZ,str(target))
    print('Installed for current Windows user only.')
    print('Chrome extension folder:',ROOT/'extension')
    print('Extension ID:',settings['extensionId'])

def uninstall():
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER,KEY) as key:
            registered=winreg.QueryValueEx(key,'')[0]
        if pathlib.Path(registered).resolve() != (ROOT/'native-host.json').resolve():
            raise RuntimeError('A different installation owns the registration; nothing changed.')
        winreg.DeleteKey(winreg.HKEY_CURRENT_USER,KEY)
        print('Native helper registration removed. Remove the extension in chrome://extensions.')
    except FileNotFoundError:
        print('Native helper was not registered.')

if __name__=='__main__':
    if '--uninstall' in sys.argv: uninstall()
    else: install()
