const idFrom = value => {
  try {
    const u = new URL(value);
    if (u.protocol !== 'https:') return null;
    const m = u.hostname === 'www-ccv.adobe.io'
      ? u.pathname.match(/^\/v1\/player\/ccv\/([A-Za-z0-9_-]{5,64})(?:\/|$)/)
      : u.hostname === 'cdn-prod-ccv.adobe.com'
        ? u.pathname.match(/^\/([A-Za-z0-9_-]{5,64})\/rend\//) : null;
    return m?.[1] || null;
  } catch { return null; }
};
// Store only video IDs, never signed URLs, headers or cookies.
let changes = Promise.resolve();
chrome.webRequest.onBeforeRequest.addListener(d => {
  const id = idFrom(d.url);
  if (d.tabId < 0 || !id) return;
  changes = changes.then(async () => {
    const key = String(d.tabId);
    const saved = (await chrome.storage.session.get(key))[key] || [];
    if (!saved.includes(id)) await chrome.storage.session.set({[key]:[...saved,id].slice(-20)});
  }).catch(() => {});
}, {urls:['https://www-ccv.adobe.io/v1/player/ccv/*','https://cdn-prod-ccv.adobe.com/*/rend/*']});
chrome.tabs.onRemoved.addListener(id => { changes = changes.then(() => chrome.storage.session.remove(String(id))); });
chrome.tabs.onUpdated.addListener((id, change) => {
  if (change.status === 'loading') changes = changes.then(() => chrome.storage.session.remove(String(id)));
});

// Content scripts cannot call Native Messaging directly. Only our Adobe
// player frames may use this bridge, and their URL determines the video ID.
const pendingFrames = new Set();
chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (message?.kind !== 'behance-idm-overlay') return;
  let videoId;
  try {
    const url = new URL(sender.url);
    if (sender.id !== chrome.runtime.id || !sender.tab ||
        url.protocol !== 'https:' || url.hostname !== 'www-ccv.adobe.io') return;
    videoId = idFrom(sender.url);
    if (!videoId || !['prepare', 'download'].includes(message.action)) return;
    if (message.action === 'download' &&
        (!Number.isInteger(message.height) || message.height < 1 || message.height > 8640)) return;
  } catch { return; }
  const key = `${sender.tab.id}:${sender.frameId}`;
  if (pendingFrames.has(key)) {
    reply({ok:false,error:'正在处理，请稍候。'});
    return;
  }
  pendingFrames.add(key);
  const request = {action:message.action,videoId};
  if (message.action === 'download') {
    request.height = message.height;
    request.title = (sender.tab.title || 'Behance').replace(/\s*::\s*Behance.*$/,'');
  }
  chrome.runtime.sendNativeMessage('local.behance_idm_helper',request,response => {
    const error = chrome.runtime.lastError;
    pendingFrames.delete(key);
    reply(error ? {ok:false,error:'本地助手未连接，请运行“安装助手.cmd”后重试。'} :
      response || {ok:false,error:'本地助手未返回结果。'});
  });
  return true;
});
