"""Personal Chrome native host. Refresh public Adobe URLs and hand MP4 to IDM."""
import concurrent.futures
import html
import json
import pathlib
import re
import struct
import sys
import urllib.error
import urllib.parse
import urllib.request

ROOT = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'vendor'))
HOST = 'local.behance_idm_helper'
PLAYER = 'https://www-ccv.adobe.io/'
CDN = 'cdn-prod-ccv.adobe.com'

def validate_id(value):
    if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9_-]{5,64}', value):
        raise ValueError('视频编号无效，请重新打开作品页面。')
    return value

def request(url, method='GET'):
    u = urllib.parse.urlsplit(url)
    if u.scheme != 'https' or u.hostname not in ('www-ccv.adobe.io', CDN) or u.username or u.password or u.port not in (None,443):
        raise ValueError('拒绝访问非 Adobe 视频地址。')
    req = urllib.request.Request(url, method=method, headers={
        'User-Agent': 'Mozilla/5.0', 'Referer': PLAYER,
        'Cache-Control': 'no-cache',
    })
    # urllib uses the current Windows system proxy. No fixed local proxy port.
    return urllib.request.urlopen(req, timeout=20)

def config(video_id):
    video_id = validate_id(video_id)
    url = PLAYER + 'v1/player/ccv/' + video_id + '/embed?api_key=behance1'
    with request(url) as r:
        body = r.read(2_000_001)
    if len(body) > 2_000_000:
        raise ValueError('播放器页面过大，已停止解析。')
    text = body.decode('utf-8')
    match = re.search(r'window\.ccv\$serverData\s*=\s*', text)
    if not match:
        raise ValueError('没有找到 Adobe 播放器信息；此作品可能不受支持。')
    data, _ = json.JSONDecoder().raw_decode(text[match.end():])
    if data.get('status') != 'ok':
        raise ValueError('播放器当前未提供可用视频。')
    return data

def advertised_heights(data):
    with request(data['m3u8URL']) as r:
        text = r.read(1_000_000).decode('utf-8')
    if not text.lstrip().startswith('#EXTM3U'):
        raise ValueError('服务器返回的播放列表无效。')
    return sorted({int(h) for h in re.findall(r'RESOLUTION=\d+x(\d+)', text)}, reverse=True)

def candidate(data, video_id, height):
    """Probe only advertised resolutions. A successful HEAD is required."""
    base = data.get('mp4URL', '')
    u = urllib.parse.urlsplit(base)
    pattern = r'/' + re.escape(video_id) + r'_\d+\.mp4$'
    if u.hostname != CDN or not re.search(pattern, u.path):
        return None
    path = re.sub(pattern, '/' + video_id + '_' + str(height) + '.mp4', u.path)
    url = urllib.parse.urlunsplit((u.scheme,u.netloc,path,u.query,''))
    try:
        with request(url, 'HEAD') as r:
            content_type = r.headers.get('Content-Type','').split(';')[0].lower()
            size = int(r.headers.get('Content-Length','0'))
            if r.status == 200 and content_type == 'video/mp4' and size > 1024:
                return {'height':height,'size':size,'url':url}
    except (urllib.error.HTTPError, urllib.error.URLError, TimeoutError, ValueError):
        return None
    return None

def resolve(video_id, selected=None):
    data = config(video_id)
    heights = advertised_heights(data)
    if selected is not None:
        if type(selected) is not int or selected not in heights:
            raise ValueError('该清晰度不在播放器列表中，请重新检测。')
        heights = [selected]
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        found = list(pool.map(lambda h: candidate(data,video_id,h), heights))
    options = [o for o in found if o]
    if not options:
        raise ValueError('未找到已验证的 MP4 文件；此视频可能仅提供 HLS，当前助手不支持。')
    return options

def send_idm(url, filename):
    import comtypes.client
    from comtypes import COMMETHOD, GUID, HRESULT, IUnknown, BSTR
    from comtypes.automation import VARIANT
    from ctypes import c_long

    class Transmitter(IUnknown):
        _iid_ = GUID('{4BD46AAE-C51F-4BF7-8BC0-2E86E33D1873}')
        _methods_ = [COMMETHOD([], HRESULT, 'SendLinkToIDM',
            *[(['in'], BSTR, name) for name in ['url','referer','cookies','data','user','password','path','filename']],
            (['in'], c_long, 'flags'))]

    class Transmitter2(Transmitter):
        _iid_ = GUID('{94D09862-1875-4FC9-B434-91CF25C840A1}')
        _methods_ = [COMMETHOD([], HRESULT, 'SendLinkToIDM2',
            *[(['in'], BSTR, name) for name in ['url','referer','cookies','data','user','password','path','filename']],
            (['in'], c_long, 'flags'), (['in'], VARIANT, 'reserved1'), (['in'], VARIANT, 'reserved2'))]

    obj = comtypes.client.CreateObject('{AC746233-E9D3-49CD-862F-068F7B7CCCA4}', interface=Transmitter2)
    # Keep IDM's normal save/start dialog; do not modify download preferences.
    obj.SendLinkToIDM2(url, PLAYER, '', '', '', '', '', filename, 0, None, None)

def handle(message):
    if not isinstance(message,dict):
        raise ValueError('请求格式无效。')
    action = message.get('action')
    if action == 'ping':
        return {'ok': True, 'version':'1.1.1'}
    video_id = validate_id(message.get('videoId'))
    if action == 'prepare':
        options = resolve(video_id)
        return {'ok':True,'options':[{k:v for k,v in o.items() if k != 'url'} for o in options]}
    if action == 'download':
        option = resolve(video_id,message.get('height'))[0]
        title = str(message.get('title','Behance'))[:100]
        title = re.sub(r'[\x00-\x1f<>:"/\\|?*]', '_', title).strip(' .') or 'Behance'
        filename = title + '-' + video_id + '-' + str(option['height']) + 'p.mp4'
        send_idm(option['url'], filename)
        return {'ok':True,'message':'已交给 IDM，请在 IDM 中确认保存并开始下载。'}
    raise ValueError('未知操作。')

def read_exact(stream, n):
    result = bytearray()
    while len(result) < n:
        chunk = stream.read(n-len(result))
        if not chunk:
            raise EOFError('Incomplete native message')
        result.extend(chunk)
    return bytes(result)

def main():
    settings = json.loads((ROOT/'settings.json').read_text(encoding='utf-8'))
    expected = 'chrome-extension://' + settings['extensionId'] + '/'
    if len(sys.argv) < 2 or sys.argv[1] != expected:
        return 2
    try:
        size = struct.unpack('<I',read_exact(sys.stdin.buffer,4))[0]
        if size > 65536:
            raise ValueError('请求过大。')
        message = json.loads(read_exact(sys.stdin.buffer,size).decode('utf-8'))
        response = handle(message)
    except ValueError as e:
        response = {'ok':False,'error':str(e)}
    except urllib.error.HTTPError as e:
        response = {'ok':False,'error':f'Adobe 服务器返回 HTTP {e.code}，请稍后重试或检查系统代理。'}
    except (urllib.error.URLError, TimeoutError):
        response = {'ok':False,'error':'连接超时或网络不可用，请检查系统代理后重试。'}
    except Exception:
        response = {'ok':False,'error':'本地助手处理失败，请确认 IDM 已安装并启动。'}
    data = json.dumps(response,ensure_ascii=False).encode('utf-8')
    sys.stdout.buffer.write(struct.pack('<I',len(data))+data)
    sys.stdout.buffer.flush()
    return 0

if __name__ == '__main__':
    sys.exit(main())
