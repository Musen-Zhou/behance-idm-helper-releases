"""Personal Chrome native host. Refresh public Adobe URLs and hand MP4 to IDM."""
import concurrent.futures
import html
import json
import pathlib
import re
import struct
import time
import sys
import urllib.error
import urllib.parse
import urllib.request

ROOT = pathlib.Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'vendor'))
HOST = 'local.behance_idm_helper'
PLAYER = 'https://www-ccv.adobe.io/'
CDN = 'cdn-prod-ccv.adobe.com'

def validate_id(value):
    if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9_-]{5,64}', value):
        raise ValueError('视频编号无效，请重新打开作品页面。')
    return value

def request(url, method='GET', byte_range=None, timeout=20):
    u = urllib.parse.urlsplit(url)
    if u.scheme != 'https' or u.hostname not in ('www-ccv.adobe.io', CDN) or u.username or u.password or u.port not in (None,443):
        raise ValueError('拒绝访问非 Adobe 视频地址。')
    req = urllib.request.Request(url, method=method, headers={
        'User-Agent': 'Mozilla/5.0', 'Referer': PLAYER,
        'Cache-Control': 'no-cache',
    })
    if byte_range is not None:
        req.add_header('Range', f'bytes={byte_range[0]}-{byte_range[1]}')
    # urllib uses the current Windows system proxy. No fixed local proxy port.
    return urllib.request.urlopen(req, timeout=timeout)

def config(video_id):
    video_id = validate_id(video_id)
    url = PLAYER + 'v1/player/ccv/' + video_id + '/embed?api_key=behance1'
    with request(url) as r:
        body = r.read(2_000_001)
    if len(body) > 2_000_000:
        raise ValueError('播放器页面过大，已停止解析。')
    text = body.decode('utf-8')
    match = re.search(r'window\.ccv\$serverData\s*=\s*', text)
    if not match:
        raise ValueError('没有找到 Adobe 播放器信息；此作品可能不受支持。')
    data, _ = json.JSONDecoder().raw_decode(text[match.end():])
    if data.get('status') != 'ok':
        raise ValueError('播放器当前未提供可用视频。')
    return data

def advertised_heights(data):
    with request(data['m3u8URL']) as r:
        text = r.read(1_000_000).decode('utf-8')
    if not text.lstrip().startswith('#EXTM3U'):
        raise ValueError('服务器返回的播放列表无效。')
    return sorted({int(h) for h in re.findall(r'RESOLUTION=\d+x(\d+)', text)}, reverse=True)

def mp4_boxes(data):
    """Yield bounded ISO BMFF child boxes, rejecting truncated containers."""
    offset = 0
    while offset < len(data):
        if len(data) - offset < 8:
            raise ValueError('Truncated MP4 box')
        size, kind = struct.unpack_from('>I4s', data, offset)
        header = 8
        if size == 1:
            if len(data) - offset < 16:
                raise ValueError('Truncated extended box')
            size = struct.unpack_from('>Q', data, offset + 8)[0]
            header = 16
        if size == 0:
            size = len(data) - offset
        if size < header or offset + size > len(data):
            raise ValueError('Invalid MP4 box size')
        yield kind, data[offset + header:offset + size]
        offset += size


def dimensions_from_moov(data):
    # Track display geometry: tkhd width/height and rotation matrix.
    # https://developer.apple.com/documentation/quicktime-file-format/track_header_atom
    dimensions = []
    for kind, track in mp4_boxes(data):
        if kind != b'trak':
            continue
        children = dict(mp4_boxes(track))
        media = dict(mp4_boxes(children.get(b'mdia', b'')))
        handler = media.get(b'hdlr', b'')
        if len(handler) < 12 or handler[8:12] != b'vide':
            continue
        tkhd = children.get(b'tkhd', b'')
        if not tkhd or tkhd[0] not in (0, 1):
            continue
        matrix_offset = 40 if tkhd[0] == 0 else 52
        if len(tkhd) < matrix_offset + 44:
            continue
        w, h = struct.unpack_from('>II', tkhd, matrix_offset + 36)
        a, b, _, c, d, _, _, _, _ = struct.unpack_from('>9i', tkhd, matrix_offset)
        # Accept orthogonal unit transforms only; do not guess custom geometry.
        if (abs(a), b, c, abs(d)) == (65536, 0, 0, 65536):
            pass
        elif (a, abs(b), abs(c), d) == (0, 65536, 65536, 0):
            w, h = h, w
        else:
            continue
        w, h = round(w / 65536), round(h / 65536)
        if 0 < w <= 65535 and 0 < h <= 65535:
            dimensions.append((w, h))
    # Multiple distinct visual tracks do not define one unambiguous size.
    unique = set(dimensions)
    return next(iter(unique)) if len(unique) == 1 else None


def mp4_dimensions(url, file_size):
    """Read at most 2 MiB of metadata; skip media data using byte ranges."""
    deadline = time.monotonic() + 12

    def read_range(start, count):
        remaining = deadline - time.monotonic()
        if remaining <= 0 or count <= 0:
            raise ValueError('Metadata budget exhausted')
        end = start + count - 1
        with request(url, byte_range=(start, end), timeout=min(4, remaining)) as r:
            expected = f'bytes {start}-{end}/{file_size}'
            if r.status != 206 or r.headers.get('Content-Range') != expected:
                raise ValueError('Server did not honor byte range')
            data = r.read(count + 1)
            if len(data) != count:
                raise ValueError('Incomplete metadata response')
            return data

    try:
        offset = 0
        for _ in range(12):
            if file_size - offset < 8:
                return None
            header = read_range(offset, min(16, file_size - offset))
            size, kind = struct.unpack_from('>I4s', header)
            header_size = 8
            if size == 1:
                if len(header) < 16:
                    return None
                size = struct.unpack_from('>Q', header, 8)[0]
                header_size = 16
            if size == 0:
                size = file_size - offset
            if size < header_size or size > file_size - offset:
                return None
            if kind == b'moov':
                if size - header_size > 2 * 1024 * 1024:
                    return None
                return dimensions_from_moov(read_range(offset + header_size, size - header_size))
            offset += size
    except (OSError, ValueError, struct.error):
        # Dimension lookup is optional; a valid MP4 must remain downloadable.
        return None
    return None


def candidate(data, video_id, height=None):
    """Validate only the exact MP4 URL advertised by the player.

    The numeric suffix is an opaque selection key, not a pixel height.
    Never derive MP4 filenames from HLS dimensions.
    """
    video_id = validate_id(video_id)
    base = data.get('mp4URL')
    if not isinstance(base, str) or not base:
        raise ValueError('播放器未提供 MP4 地址；当前助手尚不支持 HLS 分段下载。')
    u = urllib.parse.urlsplit(base)
    pattern = r'/' + re.escape(video_id) + r'/rend/' + re.escape(video_id) + r'_(\d+)\.mp4'
    match = re.fullmatch(pattern, u.path)
    if (u.scheme != 'https' or u.hostname != CDN or u.username or u.password
            or u.port not in (None, 443) or u.fragment or not match):
        raise ValueError('播放器提供的 MP4 地址不符合受支持的 Adobe 视频格式。')
    key = int(match.group(1))
    if height is not None and (type(height) is not int or height != key):
        raise ValueError('所选 MP4 已变化，请重新检测。')
    try:
        with request(base, 'HEAD') as r:
            content_type = r.headers.get('Content-Type', '').split(';')[0].strip().lower()
            size = int(r.headers.get('Content-Length', '0'))
            if r.status != 200:
                raise ValueError(f'MP4 验证失败：服务器返回 HTTP {r.status}。')
            if content_type != 'video/mp4' or size <= 1024:
                raise ValueError('MP4 验证失败：服务器未返回有效的视频类型或文件大小。')
    except urllib.error.HTTPError as e:
        if e.code == 404:
            raise ValueError('播放器提供的 MP4 地址不存在（HTTP 404），请稍后重新检测。') from e
        if e.code in (401, 403):
            raise ValueError(f'MP4 访问被拒绝（HTTP {e.code}），请重新检测以刷新链接。') from e
        raise ValueError(f'MP4 验证失败：服务器返回 HTTP {e.code}。') from e
    except (urllib.error.URLError, TimeoutError) as e:
        raise ValueError('MP4 连接超时或网络不可用，请检查网络后重新检测。') from e
    option = {'height': key, 'size': size, 'url': base,
              'label': '播放器 MP4（尺寸读取失败）'}
    dimensions = mp4_dimensions(base, size)
    if dimensions:
        width, pixel_height = dimensions
        option.update(width=width, pixelHeight=pixel_height,
                      label=f'{width}×{pixel_height} · MP4')
    return option


def resolve(video_id, selected=None):
    # Refresh the signed URL for both prepare and download. HLS availability
    # and dimensions must not gate the player's explicitly advertised MP4.
    return [candidate(config(video_id), video_id, selected)]


def send_idm(url, filename):
    import comtypes.client
    from comtypes import COMMETHOD, GUID, HRESULT, IUnknown, BSTR
    from comtypes.automation import VARIANT
    from ctypes import c_long

    class Transmitter(IUnknown):
        _iid_ = GUID('{4BD46AAE-C51F-4BF7-8BC0-2E86E33D1873}')
        _methods_ = [COMMETHOD([], HRESULT, 'SendLinkToIDM',
            *[(['in'], BSTR, name) for name in ['url','referer','cookies','data','user','password','path','filename']],
            (['in'], c_long, 'flags'))]

    class Transmitter2(Transmitter):
        _iid_ = GUID('{94D09862-1875-4FC9-B434-91CF25C840A1}')
        _methods_ = [COMMETHOD([], HRESULT, 'SendLinkToIDM2',
            *[(['in'], BSTR, name) for name in ['url','referer','cookies','data','user','password','path','filename']],
            (['in'], c_long, 'flags'), (['in'], VARIANT, 'reserved1'), (['in'], VARIANT, 'reserved2'))]

    obj = comtypes.client.CreateObject('{AC746233-E9D3-49CD-862F-068F7B7CCCA4}', interface=Transmitter2)
    # Keep IDM's normal save/start dialog; do not modify download preferences.
    obj.SendLinkToIDM2(url, PLAYER, '', '', '', '', '', filename, 0, None, None)

def handle(message):
    if not isinstance(message,dict):
        raise ValueError('请求格式无效。')
    action = message.get('action')
    if action == 'ping':
        return {'ok': True, 'version':'1.1.3'}
    video_id = validate_id(message.get('videoId'))
    if action == 'prepare':
        options = resolve(video_id)
        return {'ok':True,'options':[{k:v for k,v in o.items() if k != 'url'} for o in options]}
    if action == 'download':
        option = resolve(video_id,message.get('height'))[0]
        title = str(message.get('title','Behance'))[:100]
        title = re.sub(r'[\x00-\x1f<>:"/\\|?*]', '_', title).strip(' .') or 'Behance'
        filename = title + '-' + video_id + '-' + 'player.mp4'
        send_idm(option['url'], filename)
        return {'ok':True,'message':'已交给 IDM，请在 IDM 中确认保存并开始下载。'}
    raise ValueError('未知操作。')

def read_exact(stream, n):
    result = bytearray()
    while len(result) < n:
        chunk = stream.read(n-len(result))
        if not chunk:
            raise EOFError('Incomplete native message')
        result.extend(chunk)
    return bytes(result)

def main():
    settings = json.loads((ROOT/'settings.json').read_text(encoding='utf-8'))
    expected = 'chrome-extension://' + settings['extensionId'] + '/'
    if len(sys.argv) < 2 or sys.argv[1] != expected:
        return 2
    try:
        size = struct.unpack('<I',read_exact(sys.stdin.buffer,4))[0]
        if size > 65536:
            raise ValueError('请求过大。')
        message = json.loads(read_exact(sys.stdin.buffer,size).decode('utf-8'))
        response = handle(message)
    except ValueError as e:
        response = {'ok':False,'error':str(e)}
    except urllib.error.HTTPError as e:
        response = {'ok':False,'error':f'Adobe 服务器返回 HTTP {e.code}，请稍后重试或检查系统代理。'}
    except (urllib.error.URLError, TimeoutError):
        response = {'ok':False,'error':'连接超时或网络不可用，请检查系统代理后重试。'}
    except Exception:
        response = {'ok':False,'error':'本地助手处理失败，请确认 IDM 已安装并启动。'}
    data = json.dumps(response,ensure_ascii=False).encode('utf-8')
    sys.stdout.buffer.write(struct.pack('<I',len(data))+data)
    sys.stdout.buffer.flush()
    return 0

if __name__ == '__main__':
    sys.exit(main())
