(() => {
  if (!/^\/v1\/player\/ccv\/[A-Za-z0-9_-]{5,64}(?:\/|$)/.test(location.pathname)) return;
  if (document.getElementById('behance-idm-overlay')) return;
  const host = document.createElement('div');
  host.id = 'behance-idm-overlay';
  // Adobe embeds fill their iframe. Position relative to that iframe, not
  // the Behance page, so each video gets its own upper-left button.
  host.style.cssText = 'position:fixed!important;top:10px!important;left:10px!important;z-index:2147483647!important;width:auto!important;max-width:calc(100vw - 20px)!important;';
  const shadow = host.attachShadow({mode:'closed'});
  shadow.innerHTML = `
    <style>
      :host{color-scheme:light;font:13px/1.5 "Microsoft YaHei",sans-serif}
      *{box-sizing:border-box}button,select{font:inherit}
      button{cursor:pointer;border:0;border-radius:7px;padding:7px 11px;color:#fff;background:#175cdd}
      button:focus-visible,select:focus-visible{outline:3px solid #78b7ff;outline-offset:2px}
      button:disabled{cursor:wait;opacity:.65}
      #toggle{background:rgba(20,29,45,.9);box-shadow:0 2px 10px #0004;border:1px solid #ffffff42;white-space:nowrap}
      #toggle:hover{background:#175cdd}
      #panel{margin-top:7px;width:268px;max-width:calc(100vw - 20px);max-height:calc(100vh - 64px);overflow:auto;padding:12px;border:1px solid #dce3ed;border-radius:10px;background:#fff;color:#203047;box-shadow:0 5px 24px #0004}
      [hidden]{display:none!important}
      .head{display:flex;align-items:center;justify-content:space-between;font-weight:600}
      #close{background:transparent;color:#53647b;font-size:18px;padding:0 5px}
      select{display:block;width:100%;padding:7px;margin:9px 0;border:1px solid #cbd5e3;border-radius:6px;background:white;color:#203047}
      #status{margin:8px 0;white-space:pre-wrap;overflow-wrap:anywhere;font-size:12px}
      .note{font-size:11px;color:#68778b;margin-top:9px}
      #retry{background:#eaf0fb;color:#175cdd;margin-top:5px}
    </style>
    <button id="toggle" type="button" aria-expanded="false" aria-controls="panel">↓ 用 IDM 下载</button>
    <section id="panel" hidden aria-label="下载当前视频">
      <div class="head">下载当前视频<button id="close" type="button" aria-label="关闭">×</button></div>
      <div id="status" role="status" aria-live="polite"></div>
      <select id="quality" aria-label="可用视频" hidden></select>
      <button id="download" type="button" hidden>交给 IDM 下载</button>
      <button id="retry" type="button" hidden>重新检测</button>
      <div class="note">个人本地助手 · 下载由 IDM 完成</div>
    </section>`;
  (document.body || document.documentElement).append(host);
  const $ = id => shadow.getElementById(id);
  let busy = false;
  function call(action,extra={}) {
    return new Promise((resolve,reject) => {
      try {
        chrome.runtime.sendMessage({kind:'behance-idm-overlay',action,...extra},response => {
          if (chrome.runtime.lastError) return reject(new Error('扩展已更新或连接中断，请刷新作品页面。'));
          if (!response?.ok) return reject(new Error(response?.error || '无法连接下载助手，请刷新页面后重试。'));
          resolve(response);
        });
      } catch { reject(new Error('扩展已更新，请刷新作品页面。')); }
    });
  }
  function close() { $('panel').hidden=true;$('toggle').setAttribute('aria-expanded','false');$('toggle').focus(); }
  async function prepare() {
    if (busy) return;
    busy=true;$('retry').hidden=true;$('quality').hidden=true;$('download').hidden=true;
    $('status').textContent='正在验证播放器 MP4…';
    try {
      const r=await call('prepare');
      if (!r.options?.length) throw new Error('当前视频没有可用的 MP4。');
      $('quality').replaceChildren();
      for (const item of r.options) {
        const option=document.createElement('option');option.value=item.height;
        option.textContent=`${item.label || "播放器 MP4（画面尺寸未确认）"} · ${(item.size/1048576).toFixed(1)} MB`;
        $('quality').append(option);
      }
      $('quality').hidden=false;$('download').hidden=false;
      $('status').textContent='选择视频后交给 IDM。';
    } catch(e) { $('status').textContent=e.message; }
    finally { busy=false;$('retry').hidden=false; }
  }
  $('toggle').addEventListener('click',() => {
    if (!$('panel').hidden) return close();
    $('panel').hidden=false;$('toggle').setAttribute('aria-expanded','true');
    if (!$('quality').options.length) prepare();
  });
  $('close').addEventListener('click',close);
  $('retry').addEventListener('click',prepare);
  shadow.addEventListener('keydown',e => {if(e.key==='Escape'){e.stopPropagation();close();}});
  $('download').addEventListener('click',async() => {
    if(busy) return;
    busy=true;$('download').disabled=true;$('quality').disabled=true;$('retry').disabled=true;
    $('status').textContent='正在刷新有效链接并交给 IDM…';
    try {const r=await call('download',{height:Number($('quality').value)});$('status').textContent=r.message;}
    catch(e){$('status').textContent=e.message;}
    finally{busy=false;$('download').disabled=false;$('quality').disabled=false;$('retry').disabled=false;}
  });
})();
