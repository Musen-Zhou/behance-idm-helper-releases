const status = document.getElementById('status');
const refresh = document.getElementById('refresh');
const list = document.getElementById('videos');
const host = 'local.behance_idm_helper';
function native(message) {
  return new Promise((resolve,reject) => chrome.runtime.sendNativeMessage(host,message,response => {
    const error = chrome.runtime.lastError;
    if (error) return reject(new Error('本地助手未连接。请运行安装助手.cmd，再重新打开扩展。'));
    if (!response?.ok) return reject(new Error(response?.error || '助手没有返回结果。'));
    resolve(response);
  }));
}
function idFrom(value) {
  try {
    const u = new URL(value);
    if (u.protocol !== 'https:') return null;
    if(u.hostname === 'www-ccv.adobe.io') return u.pathname.match(/^\/v1\/player\/ccv\/([A-Za-z0-9_-]{5,64})(?:\/|$)/)?.[1];
    if(u.hostname === 'cdn-prod-ccv.adobe.com') return u.pathname.match(/^\/([A-Za-z0-9_-]{5,64})\/rend\//)?.[1];
  } catch {}
  return null;
}
async function scan() {
  refresh.disabled=true; list.replaceChildren(); status.textContent='正在检测当前页面…';
  try {
    const [tab] = await chrome.tabs.query({active:true,currentWindow:true});
    if(!tab?.id || !/^https:\/\/(www\.)?behance\.net\//.test(tab.url || '') && !/^https:\/\/www-ccv\.adobe\.io\//.test(tab.url || '')) {
      throw new Error('请先切换到 Behance 作品或 Adobe 独立播放器页面。');
    }
    await native({action:'ping'});
    const saved=(await chrome.storage.session.get(String(tab.id)))[String(tab.id)] || [];
    const ids=new Set(saved); const direct=idFrom(tab.url); if(direct) ids.add(direct);
    const results=await chrome.scripting.executeScript({target:{tabId:tab.id},func:()=>
      [...document.querySelectorAll('iframe[src],video[src],source[src]')].map(e=>e.src)
    });
    for(const r of results) for(const src of r.result || []) {const id=idFrom(src);if(id)ids.add(id);}
    if(!ids.size) throw new Error('尚未发现 Adobe 视频。请滚动到视频、播放几秒后重新检测。');
    let count=0;
    for(const videoId of [...ids].slice(0,8)) {
      status.textContent=`正在核验视频 ${++count}/${Math.min(ids.size,8)} 的可用 MP4…`;
      const card=document.createElement('div');card.className='card';list.append(card);
      const label=document.createElement('div');label.textContent=`视频 ${count} · ${videoId}`;card.append(label);
      try {
        const response=await native({action:'prepare',videoId});
        const select=document.createElement('select');
        for(const item of response.options){const o=document.createElement('option');o.value=item.height;o.textContent=`${item.label || "播放器 MP4（画面尺寸未确认）"} · ${(item.size/1048576).toFixed(1)} MB`;select.append(o);}
        card.append(select);
        const button=document.createElement('button');button.textContent='用 IDM 下载';card.append(button);
        const message=document.createElement('div');message.className='note';card.append(message);
        button.addEventListener('click',async()=>{
          button.disabled=true;message.textContent='正在刷新有效链接并交给 IDM…';
          try {const r=await native({action:'download',videoId,height:Number(select.value),title:(tab.title || 'Behance').replace(/\s*::\s*Behance.*$/,'')});message.textContent=r.message;}
          catch(e){message.textContent=e.message;}
          finally{button.disabled=false;}
        });
      } catch(e){const message=document.createElement('div');message.textContent=e.message;card.append(message);}
    }
    status.textContent='检测完成。选择视频后交给 IDM。';
  } catch(e){status.textContent=e.message;}
  finally{refresh.disabled=false;}
}
refresh.addEventListener('click',scan);scan();
