import importlib.util,io,pathlib,struct,unittest
from unittest.mock import patch
root=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('h',root/'host.py');h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
def box(kind,data):return struct.pack('>I4s',len(data)+8,kind)+data
def track(w=1920,height=416,version=0,rotate=False,handler=b'vide'):
    offset=40 if version==0 else 52
    tkhd=bytearray(offset+44);tkhd[0]=version
    matrix=(0,65536,0,-65536,0,0,0,0,1<<30) if rotate else (65536,0,0,0,65536,0,0,0,1<<30)
    struct.pack_into('>9iII',tkhd,offset,*matrix,w<<16,height<<16)
    return box(b'trak',box(b'tkhd',tkhd)+box(b'mdia',box(b'hdlr',b'\0'*8+handler+b'\0'*12)))
class Tests(unittest.TestCase):
    def test_versions_rotation_and_audio(self):
        for version in [0,1]:
            self.assertEqual(h.dimensions_from_moov(track(version=version)),(1920,416))
            self.assertEqual(h.dimensions_from_moov(track(version=version,rotate=True)),(416,1920))
        self.assertIsNone(h.dimensions_from_moov(track(handler=b'soun')))
        self.assertIsNone(h.dimensions_from_moov(track()+track(1280,720)))

    def test_reads_tail_moov_without_downloading_media(self):
        data=box(b'ftyp',b'isom\0\0\0\0')+box(b'mdat',b'\0'*3000000)+box(b'moov',track())
        reads=[]
        def request(url,byte_range,timeout):
            a,b=byte_range;reads.append((a,b));r=io.BytesIO(data[a:b+1]);r.status=206;r.headers={'Content-Range':f'bytes {a}-{b}/{len(data)}'};return r
        with patch.object(h,'request',side_effect=request):
            self.assertEqual(h.mp4_dimensions('URL',len(data)),(1920,416))
        self.assertLess(sum(b-a+1 for a,b in reads),1024)

    def test_range_ignored_and_network_failure_are_optional(self):
        r=io.BytesIO(b'not mp4');r.status=200;r.headers={}
        with patch.object(h,'request',return_value=r):self.assertIsNone(h.mp4_dimensions('URL',1000))
        with patch.object(h,'request',side_effect=TimeoutError()):self.assertIsNone(h.mp4_dimensions('URL',1000))

    def test_malformed_boxes_rejected(self):
        for data in [b'abc',struct.pack('>I4s',7,b'trak'),struct.pack('>I4s',100,b'trak')]:
            with self.assertRaises(ValueError):h.dimensions_from_moov(data)

    def test_candidate_returns_measured_dimensions(self):
        r=io.BytesIO();r.status=200;r.headers={'Content-Type':'video/mp4','Content-Length':'123456'}
        with patch.object(h,'request',return_value=r),patch.object(h,'mp4_dimensions',return_value=(1920,416)):
            option=h.candidate({'mp4URL':'https://cdn-prod-ccv.adobe.com/Ie32IaLYWBo/rend/Ie32IaLYWBo_720.mp4'},'Ie32IaLYWBo')
        self.assertEqual(option['label'],'1920×416 · MP4')
        self.assertEqual(option['pixelHeight'],416)
        self.assertEqual(option['height'],720) # legacy selection key, never displayed

if __name__=='__main__':unittest.main()
