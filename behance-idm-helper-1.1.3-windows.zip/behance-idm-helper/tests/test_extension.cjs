const fs=require('fs'),vm=require('vm'),assert=require('assert');
const root=require('path').resolve(__dirname,'..');
let checks=0;
const noop=()=>{};let listener;let forwarded;
const chrome={webRequest:{onBeforeRequest:{addListener:noop}},tabs:{onRemoved:{addListener:noop},onUpdated:{addListener:noop}},runtime:{id:'test',onMessage:{addListener:f=>listener=f},sendNativeMessage:(h,m,cb)=>{forwarded=m;cb({ok:true})}}};
const bg=vm.createContext({URL,chrome});vm.runInContext(fs.readFileSync(root+'/extension/background.js','utf8')+'\nglobalThis.extract=idFrom;',bg);
const popup=vm.createContext({URL,document:{getElementById:()=>({addEventListener:noop})}});vm.runInContext(fs.readFileSync(root+'/extension/popup.js','utf8').replace('refresh.addEventListener(\'click\',scan);scan();',''),popup);
for(const ctx of [bg,popup]) {
 const fn=ctx.extract||ctx.idFrom;
 for(const id of ['6NixcLLc_Be','78uzZhW6jLF','Abc-d_Ef12','a'.repeat(5),'a'.repeat(64)]) {
  for(const url of [`https://www-ccv.adobe.io/v1/player/ccv/${id}/embed?api_key=behance1`,`https://cdn-prod-ccv.adobe.com/${id}/rend/${id}_1080.mp4?token=x`]){assert.equal(fn(url),id);checks++}
 }
 for(const url of ['https://evil.example/v1/player/ccv/6NixcLLc_Be/embed','http://www-ccv.adobe.io/v1/player/ccv/6NixcLLc_Be/embed',...['abc%2Fdef','abcd','a'.repeat(65),'abc.def'].map(id=>`https://www-ccv.adobe.io/v1/player/ccv/${id}/embed`)]){assert.ok(!fn(url));checks++}
}
listener({kind:'behance-idm-overlay',action:'download',height:1080},{id:'test',tab:{id:1,title:'TORRAS'},frameId:2,url:'https://www-ccv.adobe.io/v1/player/ccv/6NixcLLc_Be/embed'},noop);assert.equal(forwarded.videoId,'6NixcLLc_Be');checks++;
const overlay=fs.readFileSync(root+'/extension/overlay.js','utf8');
for(const id of ['6NixcLLc_Be','78uzZhW6jLF','Abc-d_Ef12','abc%2Fdef','abcd','a'.repeat(65)]) {
 let entered=false;
 vm.runInNewContext(overlay,{location:{pathname:`/v1/player/ccv/${id}/embed`},document:{getElementById:()=>{entered=true;return {}}}});
 assert.equal(entered,['6NixcLLc_Be','78uzZhW6jLF','Abc-d_Ef12'].includes(id));checks++;
}
console.log(`${checks} JavaScript regression checks passed using native URL`);