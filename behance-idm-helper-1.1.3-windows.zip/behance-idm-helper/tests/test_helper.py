import importlib.util
import io
import json
import pathlib
import struct
import subprocess
import sys
import unittest
from unittest.mock import patch

ROOT=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('helper',ROOT/'host.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)

class Reply(io.BytesIO):
    status=200
    headers={'Content-Type':'video/mp4','Content-Length':'123456'}

class Tests(unittest.TestCase):
    def setUp(self):
        dims=patch.object(h, "mp4_dimensions", return_value=None)
        dims.start()
        self.addCleanup(dims.stop)

    def test_video_id_rejects_paths_and_commands(self):
        for value in ['../bad','a&calc','https://evil.example','short',None]:
            if value=='short': continue
            with self.assertRaises(ValueError):h.validate_id(value)

    def test_url_safe_ids(self):
        for value in ['6NixcLLc_Be', '78uzZhW6jLF', 'Abc-d_Ef12', 'a'*5, 'a'*64]:
            self.assertEqual(h.validate_id(value), value)
        for value in ['abcd', 'a'*65, 'abc/def', 'abc?def', 'abc#def', 'abc%2Fdef', 'abc.def']:
            with self.assertRaises(ValueError): h.validate_id(value)

    def test_url_safe_mp4_keeps_signature(self):
        for video_id in ['6NixcLLc_Be', 'Abc-d_Ef12']:
            base=f'https://cdn-prod-ccv.adobe.com/{video_id}/rend/{video_id}_576.mp4?hdnts=a%3Db%7Ec&x=a+b'
            with patch.object(h, 'request', return_value=Reply()):
                result=h.candidate({'mp4URL':base}, video_id, 576)
            self.assertEqual(result['url'], base)

    def test_version(self):
        self.assertEqual(h.handle({'action':'ping'})['version'], '1.1.3')

    def test_cdn_url_guard(self):
        for url in ['http://cdn-prod-ccv.adobe.com/x','https://evil.example/x','https://www-ccv.adobe.io@evil.example/x']:
            with self.assertRaises(ValueError):h.request(url)

    def test_preserves_exact_query(self):
        base='https://cdn-prod-ccv.adobe.com/78uzZhW6jLF/rend/78uzZhW6jLF_576.mp4?hdnts=a%3Db%7Ec&x=a+b'
        with patch.object(h,'request',return_value=Reply()) as request:
            item=h.candidate({'mp4URL':base},'78uzZhW6jLF',576)
        self.assertEqual(item['url'],base)
        self.assertEqual(request.call_args.args[1],'HEAD')

    def test_rejects_html_even_with_status_200(self):
        r=Reply();r.headers={'Content-Type':'text/html','Content-Length':'123456'}
        with patch.object(h,'request',return_value=r):
            with self.assertRaisesRegex(ValueError, '视频类型'):
                h.candidate({'mp4URL':'https://cdn-prod-ccv.adobe.com/78uzZhW6jLF/rend/78uzZhW6jLF_576.mp4'},'78uzZhW6jLF',576)

    def test_unadvertised_height(self):
        with patch.object(h,'config',return_value={}),patch.object(h,'advertised_heights',return_value=[1080]):
            with self.assertRaises(ValueError):h.resolve('78uzZhW6jLF',2160)

    def test_no_signed_url_in_prepare_response(self):
        with patch.object(h,'resolve',return_value=[{'height':1080,'size':123456,'url':'SECRET'}]):
            result=h.handle({'action':'prepare','videoId':'78uzZhW6jLF'})
        self.assertNotIn('SECRET',json.dumps(result))

    def test_native_origin_and_framing(self):
        origin='chrome-extension://'+json.loads((ROOT/'settings.json').read_text())['extensionId']+'/'
        message=json.dumps({'action':'ping'}).encode();frame=struct.pack('<I',len(message))+message
        p=subprocess.run([sys.executable,str(ROOT/'host.py'),origin],input=frame,capture_output=True,timeout=10)
        self.assertEqual(p.returncode,0)
        self.assertEqual(struct.unpack('<I',p.stdout[:4])[0],len(p.stdout)-4)
        self.assertTrue(json.loads(p.stdout[4:])['ok'])
        p=subprocess.run([sys.executable,str(ROOT/'host.py'),'chrome-extension://wrong/'],input=frame,capture_output=True,timeout=10)
        self.assertEqual(p.returncode,2);self.assertEqual(p.stdout,b'')

    def test_partial_stream_read(self):
        class Partial(io.BytesIO):
            def read(self,n):return super().read(min(n,2))
        self.assertEqual(h.read_exact(Partial(b'abcdef'),6),b'abcdef')


    def test_ultrawide_uses_exact_mp4_without_hls(self):
        base='https://cdn-prod-ccv.adobe.com/Ie32IaLYWBo/rend/Ie32IaLYWBo_720.mp4?hdnts=a%3Db%7Ec&x=a+b'
        with patch.object(h,'config',return_value={'mp4URL':base}), patch.object(h,'advertised_heights',side_effect=AssertionError('Must not request HLS')), patch.object(h,'request',return_value=Reply()) as req:
            result=h.resolve('Ie32IaLYWBo',720)[0]
        self.assertEqual(result['url'],base)
        self.assertEqual(result['label'],'播放器 MP4（尺寸读取失败）')
        req.assert_called_once_with(base,'HEAD')

    def test_invalid_selection_never_rewrites_url(self):
        base='https://cdn-prod-ccv.adobe.com/Ie32IaLYWBo/rend/Ie32IaLYWBo_720.mp4'
        for selected in [416,278,222,True,'720']:
            with patch.object(h,'config',return_value={'mp4URL':base}),patch.object(h,'request') as req:
                with self.assertRaises(ValueError):h.resolve('Ie32IaLYWBo',selected)
                req.assert_not_called()

    def test_download_refreshes_signed_url_and_avoids_fake_resolution(self):
        base='https://cdn-prod-ccv.adobe.com/Ie32IaLYWBo/rend/Ie32IaLYWBo_720.mp4?hdnts='
        with patch.object(h,'config',side_effect=[{'mp4URL':base+'old'},{'mp4URL':base+'fresh'}]),patch.object(h,'request',side_effect=lambda *a:Reply()),patch.object(h,'send_idm') as send:
            prepared=h.handle({'action':'prepare','videoId':'Ie32IaLYWBo'})
            result=h.handle({'action':'download','videoId':'Ie32IaLYWBo','height':prepared['options'][0]['height'],'title':'FORCE'})
        self.assertTrue(result['ok'])
        self.assertEqual(send.call_args.args[0],base+'fresh')
        self.assertNotIn('720p',send.call_args.args[1])
        self.assertNotIn('hdnts',json.dumps(prepared))

    def test_exact_url_guard(self):
        for base in ['http://cdn-prod-ccv.adobe.com/Ie32IaLYWBo/rend/Ie32IaLYWBo_720.mp4','https://evil.example/Ie32IaLYWBo/rend/Ie32IaLYWBo_720.mp4','https://cdn-prod-ccv.adobe.com/other/rend/Ie32IaLYWBo_720.mp4','https://user@cdn-prod-ccv.adobe.com/Ie32IaLYWBo/rend/Ie32IaLYWBo_720.mp4']:
            with patch.object(h,'request') as req:
                with self.assertRaises(ValueError):h.candidate({'mp4URL':base},'Ie32IaLYWBo')
                req.assert_not_called()

    def test_probe_errors_are_distinguished(self):
        base='https://cdn-prod-ccv.adobe.com/Ie32IaLYWBo/rend/Ie32IaLYWBo_720.mp4'
        for error,expected in [(h.urllib.error.HTTPError(base,404,'missing',{},None),'404'),(h.urllib.error.HTTPError(base,403,'denied',{},None),'403'),(h.urllib.error.URLError('offline'),'网络')]:
            with patch.object(h,'request',side_effect=error):
                with self.assertRaisesRegex(ValueError,expected):h.candidate({'mp4URL':base},'Ie32IaLYWBo')

if __name__=='__main__':unittest.main()
