# Behance → IDM 本地助手

在 Behance 的 Adobe 视频左上角显示下载按钮，自动获取有效 MP4 地址并交给正版 IDM。个人工具，非 Adobe 或 IDM 官方扩展。

## 安装到另一台 Windows 电脑

1. 安装 Chrome、Python 3.10 或更新版本（建议 Python 3.12）以及已获授权的 IDM，并启动 IDM 一次。
2. 从仓库的 Code → Download ZIP 下载源码，解压到固定目录。
3. 双击 `install.cmd`。首次安装会通过 pip 下载固定版本的 comtypes 到本目录的 vendor 文件夹，然后注册当前用户的本地助手。无需管理员权限。
4. Chrome 打开 `chrome://extensions/`，开启开发者模式，选择“加载已解压的扩展程序”，选中 `extension` 文件夹。
5. 刷新 Behance 作品页面，点击视频左上角的“用 IDM 下载”，选择清晰度，再在 IDM 中确认下载。

IDM 软件与注册码不包含在仓库中。迁移电脑或分享本工具不迁移 IDM 授权；每位使用者自行安装并取得适用的 IDM 授权。

保留原有 IDM Integration Module。本助手与原扩展并存，右上角留给原 IDM 视频嗅探浮窗。

## 更新

当前采用手动更新，不会静默下载或执行远程代码。

1. 备份原文件夹，阅读 CHANGELOG.md。
2. 下载新版源码，将源码覆盖到原安装目录。不要删掉运行时生成的 `vendor`、`native-host.cmd`、`native-host.json`。
3. 运行一次 `install.cmd`，确认依赖和本机路径可用。
4. 在 `chrome://extensions/` 重新加载本扩展，并刷新视频页面。

也可以使用 Git 克隆仓库，更新时先确认没有未保存修改，再使用 `git pull --ff-only`。有本地修改或冲突时不要强制覆盖，交给维护者处理。

扩展 manifest 中的公开 key 与 settings.json 中的 extensionId 用于保持扩展身份稳定，不是密码，不应随意重新生成。日后可通过 GitHub Releases 发布有版本号的安装包、查看历史修改和回退版本。

## 适用范围

支持能公开解析且存在可访问 MP4 文件的 Adobe Creative Cloud 视频。读取播放器公布的清晰度，并核验 MP4 返回状态、类型与大小；没有可用 MP4 时明确报错。

不是通用 HLS 或 DRM 下载工具。仅有 HLS、第三方播放器、登录限制或网站接口变化，都可能需要后续维护。

助手只读取相关 Adobe 信息，实际视频由 IDM 下载。本地助手使用 Windows 系统代理，无需写死 FLClash 或其他软件的端口。

## 备份范围与隐私

仓库包含扩展源码、助手源码、便携安装入口、依赖版本、测试和更新记录。排除本机路径配置、下载视频、临时令牌、Cookie、账号信息、注册码、Python 缓存和本机测试数据。

仅按浏览器标签页临时保存视频编号；不保存签名地址和完整浏览历史，不使用云端中转，没有常驻监听端口。

## 卸载

在 Chrome 移除此扩展，再运行 `uninstall.cmd`。该脚本仅移除与本目录匹配的助手注册项，不删除下载视频，不修改 IDM 授权。然后可自行删除本目录。

## 测试与维护

运行 `python tests/test_helper.py`；检查 JavaScript 时运行 `node --check extension/overlay.js` 等命令。

反馈请附作品链接、报错文字、Chrome/IDM 版本以及是否只影响一个视频。不要提交带 hdnts 的完整临时链接、Cookie 或注册码。

已在原电脑通过用户安装测试；原测试作品的 1080P MP4 为 47,371,693 字节、1920×1080、约 77.16 秒。新电脑完整安装仍需在目标电脑验证。

## 分享与第三方依赖

私有仓库只有被授权的账号能够访问。需要分享时可邀请指定协作者，或单独分享不含本机配置的源码包。尚未选择本项目的开源许可证；公开发布前再决定授权方式。

comtypes 1.4.17 通过 PyPI 安装，受其自身许可证约束。IDM 官方接口文档对第三方扩展商店发行有明确限制；本仓库用于个人本地安装，不等同于获准上架 Chrome 商店。

- IDM API：https://www.internetdownloadmanager.com/support/idm_api.html
- Chrome Native Messaging：https://developer.chrome.com/docs/extensions/develop/concepts/native-messaging
